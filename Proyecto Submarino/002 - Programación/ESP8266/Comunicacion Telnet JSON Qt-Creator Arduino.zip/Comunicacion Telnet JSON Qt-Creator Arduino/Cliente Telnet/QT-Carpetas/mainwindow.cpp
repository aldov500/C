#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QProcess>
#include <QTcpSocket>
#include <QTimer>
#include <stdlib.h>

/*::::::::::::::::::::::::::::VARIABLES GLOBALES::::::::::::::::::::::::::::*/
QProcess telnet;
QProcess wifiConexion;

QString lectura;

QString Led01_High = "{\"LED_01\":\"HIGH\"}\n";
QString Led01_Down = "{\"LED_01\":\"DOWN\"}\n";

QString Led02_High = "{\"LED_02\":\"HIGH\"}\n";
QString Led02_Down = "{\"LED_02\":\"DOWN\"}\n";

QString Led03_High = "{\"LED_03\":\"HIGH\"}\n";
QString Led03_Down = "{\"LED_03\":\"DOWN\"}\n";


/*::::::::::::::::::::::::::::PROTOTIPOS DE FUNCIONES ::::::::::::::::::::::::::::*/
QString EscribirTelnet(QString Mensaje);
QString LeerTelnet();

/*::::::::::::::::::::::::::::FUNCION PRINCIPAL::::::::::::::::::::::::::::*/
MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow) {

    ui->setupUi(this);
    QTimer* loop = new QTimer(this);

    TelnetConexion();

    connect(loop, SIGNAL(timeout()), this, SLOT(funcionLoop()));
    loop->start(100);
}

/*::::::::::::::::::::::::::::FUNCION REPETITIVA::::::::::::::::::::::::::::*/
void MainWindow::funcionLoop(){

    lectura = LeerTelnet();

    if(!lectura.isEmpty()){
        ui->LBL_Respuesta->setText(lectura);
    }

}

/*::::::::::::::::::::::::::::BOTON TELNET::::::::::::::::::::::::::::*/

void MainWindow::on_BTN_EnviarTelnet_clicked()
{
    EscribirTelnet(ui->EDT_ComandoTelnet->text());
}


/*::::::::::::::::::::::::::::BOTONES LEDS::::::::::::::::::::::::::::*/

void MainWindow::on_BTN_Led01_clicked(bool checked)
{
    if(checked == true){
        EscribirTelnet(Led01_High);
    } else {
        EscribirTelnet(Led01_Down);
    }

}

void MainWindow::on_BTN_Led02_clicked(bool checked)
{
    if(checked == true){
        EscribirTelnet(Led02_High);
    } else {
        EscribirTelnet(Led02_Down);
    }
}

void MainWindow::on_BTN_Led03_clicked(bool checked)
{
    if(checked == true){
        EscribirTelnet(Led03_High);
    } else {
        EscribirTelnet(Led03_Down);
    }
}


/*::::::::::::::::::::::::::::BOTON CONECTAR::::::::::::::::::::::::::::*/

void MainWindow::on_BTN_ConectarHotSPot_clicked()
{
    wifiConexion.start("nmcli c up ECOVAPO");

    wifiConexion.waitForFinished(-1); // will wait forever until finished

    ui->LBL_Respuesta->setText(wifiConexion.readAllStandardOutput());
}

/*::::::::::::::::::::::::::::CONEXION INICIAL::::::::::::::::::::::::::::*/
void MainWindow::TelnetConexion(){
    telnet.start("telnet 192.168.1.1 23");

    telnet.waitForFinished(10);

    ui->LBL_Respuesta->setText(telnet.readAllStandardOutput());

}


/*::::::::::::::::::::::::::::FUNCION ESCRIBIR::::::::::::::::::::::::::::*/
QString MainWindow::EscribirTelnet(QString Mensaje){

    telnet.write(Mensaje.toUtf8().constData());
    telnet.waitForFinished(1);

    QString stdout = telnet.readAllStandardOutput();
    QString stderr = telnet.readAllStandardError();
    qDebug() << stdout;
    return stdout;

}


/*::::::::::::::::::::::::::::FUNCION LEER::::::::::::::::::::::::::::*/
QString LeerTelnet(){

    QString stdout = telnet.readAllStandardOutput();
    QString stderr = telnet.readAllStandardError();

    if(!stdout.isEmpty()){
        qDebug() << stdout;
        return stdout;
    }
    return "";
}


/*:::::::::::::::::::::::::::: DESTRUCTOR ::::::::::::::::::::::::::::*/
MainWindow::~MainWindow() { delete ui; }








