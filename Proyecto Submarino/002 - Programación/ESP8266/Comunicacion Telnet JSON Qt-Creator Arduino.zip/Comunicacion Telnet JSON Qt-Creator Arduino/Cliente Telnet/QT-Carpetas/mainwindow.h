#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void TelnetConexion();

    QString EscribirTelnet(QString Mensaje);

public slots:
    void funcionLoop();

private slots:

    void on_BTN_ConectarHotSPot_clicked();

    void on_BTN_EnviarTelnet_clicked();

    void on_BTN_Led01_clicked(bool checked);

    void on_BTN_Led02_clicked(bool checked);

    void on_BTN_Led03_clicked(bool checked);


private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
