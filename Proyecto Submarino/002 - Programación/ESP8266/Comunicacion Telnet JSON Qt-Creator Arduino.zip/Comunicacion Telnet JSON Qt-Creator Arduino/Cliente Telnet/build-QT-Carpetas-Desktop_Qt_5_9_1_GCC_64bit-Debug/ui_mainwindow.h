/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *LBL_Respuesta;
    QPushButton *BTN_ConectarHotSPot;
    QPushButton *BTN_EnviarTelnet;
    QLineEdit *EDT_ComandoTelnet;
    QPushButton *BTN_Led01;
    QPushButton *BTN_Led03;
    QPushButton *BTN_Led02;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(357, 342);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        LBL_Respuesta = new QLabel(centralWidget);
        LBL_Respuesta->setObjectName(QStringLiteral("LBL_Respuesta"));
        LBL_Respuesta->setGeometry(QRect(20, 90, 241, 191));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        LBL_Respuesta->setFont(font);
        LBL_Respuesta->setFrameShape(QFrame::Box);
        BTN_ConectarHotSPot = new QPushButton(centralWidget);
        BTN_ConectarHotSPot->setObjectName(QStringLiteral("BTN_ConectarHotSPot"));
        BTN_ConectarHotSPot->setGeometry(QRect(20, 10, 101, 31));
        BTN_EnviarTelnet = new QPushButton(centralWidget);
        BTN_EnviarTelnet->setObjectName(QStringLiteral("BTN_EnviarTelnet"));
        BTN_EnviarTelnet->setGeometry(QRect(20, 50, 101, 31));
        EDT_ComandoTelnet = new QLineEdit(centralWidget);
        EDT_ComandoTelnet->setObjectName(QStringLiteral("EDT_ComandoTelnet"));
        EDT_ComandoTelnet->setGeometry(QRect(130, 50, 201, 31));
        BTN_Led01 = new QPushButton(centralWidget);
        BTN_Led01->setObjectName(QStringLiteral("BTN_Led01"));
        BTN_Led01->setGeometry(QRect(270, 90, 61, 51));
        BTN_Led01->setCheckable(true);
        BTN_Led03 = new QPushButton(centralWidget);
        BTN_Led03->setObjectName(QStringLiteral("BTN_Led03"));
        BTN_Led03->setGeometry(QRect(270, 230, 61, 51));
        BTN_Led03->setCheckable(true);
        BTN_Led02 = new QPushButton(centralWidget);
        BTN_Led02->setObjectName(QStringLiteral("BTN_Led02"));
        BTN_Led02->setGeometry(QRect(270, 160, 61, 51));
        BTN_Led02->setCheckable(true);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 357, 18));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        LBL_Respuesta->setText(QString());
        BTN_ConectarHotSPot->setText(QApplication::translate("MainWindow", "Conectar HotSpot", Q_NULLPTR));
        BTN_EnviarTelnet->setText(QApplication::translate("MainWindow", "TELNET", Q_NULLPTR));
        BTN_Led01->setText(QApplication::translate("MainWindow", "LED 01", Q_NULLPTR));
        BTN_Led03->setText(QApplication::translate("MainWindow", "LED 03", Q_NULLPTR));
        BTN_Led02->setText(QApplication::translate("MainWindow", "LED 02", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
