<!--
Thanks for using ArduinoJson :-)

Before opening an issue, please make sure you've read these:
https://github.com/bblanchon/ArduinoJson/wiki/FAQ
https://github.com/bblanchon/ArduinoJson/wiki/Avoiding-pitfalls

Next, make sure you provide all the relevant information: platform, code snippet, and error messages.

Please be concise!
-->